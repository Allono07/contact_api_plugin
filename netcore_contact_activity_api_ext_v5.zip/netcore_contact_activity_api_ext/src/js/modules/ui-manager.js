// UI Manager - Handles all UI interactions and updates

class UIManager {
    constructor() {
        this.attributeCounter = 0;
    }

    /**
     * Get default value based on data type
     */
    getDefaultValue(dataType, isEvent = false) {
        switch (dataType) {
            case DATA_TYPES.float:
                return '12.1';
            case DATA_TYPES.number:
                return '22';
            case DATA_TYPES.string:
                return 'test';
            case DATA_TYPES.date:
                return isEvent ? '2025-09-22 12:12:12' : '2025-09-22';
            default:
                return '';
        }
    }

    /**
     * Initialize all event listeners
     */
    initializeEventListeners() {
        // Contact API listeners
        document.getElementById('addAttributeBtn').addEventListener('click', () => this.addAttributeRow());
        document.getElementById('generateCurlBtn').addEventListener('click', () => this.handleGenerateCurl());
        document.getElementById('triggerApiBtn').addEventListener('click', () => this.handleTriggerAPI());
        document.getElementById('previewContactBtn').addEventListener('click', () => this.handleContactPreview());
        document.getElementById('toggleApiKey').addEventListener('click', () => this.toggleApiKeyVisibility());
        document.getElementById('clearContactFormBtn').addEventListener('click', () => this.handleClearContactForm());

        // Contact V5 Listeners
        document.querySelectorAll('.api-type-btn[data-version]').forEach(btn => {
            btn.addEventListener('click', (e) => this.handleVersionSwitch(e.target.dataset.version));
        });

        const addSystemAttrBtn = document.getElementById('addSystemAttributeBtn');
        const addCustomAttrBtn = document.getElementById('addCustomAttributeBtn');
        const generateCurlBtnV5 = document.getElementById('generateCurlBtnV5');
        const triggerApiBtnV5 = document.getElementById('triggerApiBtnV5');
        const clearContactFormBtnV5 = document.getElementById('clearContactFormBtnV5');
        const toggleApiKeyV5 = document.getElementById('toggleApiKeyV5');
        const contactTypeV5 = document.getElementById('contactTypeV5');

        if (addSystemAttrBtn) addSystemAttrBtn.addEventListener('click', () => this.addAttributeRowV5('system'));
        if (addCustomAttrBtn) addCustomAttrBtn.addEventListener('click', () => this.addAttributeRowV5('custom'));
        if (generateCurlBtnV5) generateCurlBtnV5.addEventListener('click', () => this.handleGenerateCurlV5());
        if (triggerApiBtnV5) triggerApiBtnV5.addEventListener('click', () => this.handleTriggerAPIV5());
        if (previewContactBtnV5) previewContactBtnV5.addEventListener('click', () => this.handleContactPreviewV5());
        if (clearContactFormBtnV5) clearContactFormBtnV5.addEventListener('click', () => this.handleClearContactFormV5());
        if (toggleApiKeyV5) toggleApiKeyV5.addEventListener('click', () => this.toggleApiKeyVisibilityV5());
        
        if (contactTypeV5) {
             contactTypeV5.addEventListener('change', (e) => {
                 this.toggleIdentityField(e.target.value);
                 this.saveFormState();
             });
        }

        ['regionV5', 'apiKeyV5', 'operationV5', 'audienceIdV5', 'identityV5'].forEach(id => {
             const el = document.getElementById(id);
             if (el) el.addEventListener('change', () => this.saveFormState());
         });

        // Activity API listeners
        const addActivityBtn = document.getElementById('addActivityBtn');
        const generateActivityCurlBtn = document.getElementById('generateActivityCurlBtn');
        const triggerActivityApiBtn = document.getElementById('triggerActivityApiBtn');
        const previewActivityBtn = document.getElementById('previewActivityBtn');
        const toggleActivityApiKey = document.getElementById('toggleActivityApiKey');
        const uploadCsvBtn = document.getElementById('uploadCsvBtn');
        const clearActivityFormBtn = document.getElementById('clearActivityFormBtn');

        if (addActivityBtn) addActivityBtn.addEventListener('click', () => this.addActivityRow());
        if (generateActivityCurlBtn) generateActivityCurlBtn.addEventListener('click', () => this.handleGenerateActivityCurl());
        if (triggerActivityApiBtn) triggerActivityApiBtn.addEventListener('click', () => this.handleTriggerActivityAPI());
        if (previewActivityBtn) previewActivityBtn.addEventListener('click', () => this.handleActivityPreview());
        if (toggleActivityApiKey) toggleActivityApiKey.addEventListener('click', () => this.toggleActivityApiKeyVisibility());
        if (uploadCsvBtn) uploadCsvBtn.addEventListener('click', () => this.handleCSVUpload());
        if (clearActivityFormBtn) clearActivityFormBtn.addEventListener('click', () => this.handleClearActivityForm());

        // Response listeners
        document.getElementById('copyCurlBtn').addEventListener('click', () => this.handleCopyCurl());
        document.getElementById('triggerCurlBtn').addEventListener('click', () => this.handleTriggerCurl());
        document.getElementById('closeCurlBtn').addEventListener('click', () => this.closeCurlSection());
        document.getElementById('copyResponseBtn').addEventListener('click', () => this.handleCopyResponse());
        document.getElementById('closeResponseBtn').addEventListener('click', () => this.closeResponseSection());
        
        // Modal listeners
        const closePreviewBtn = document.getElementById('closePreviewBtn');
        const previewModal = document.getElementById('previewModal');
        
        if (closePreviewBtn) {
            closePreviewBtn.addEventListener('click', () => this.closePreviewModal());
        }
        
        if (previewModal) {
            window.addEventListener('click', (event) => {
                if (event.target === previewModal) {
                    this.closePreviewModal();
                }
            });
        }
    }

    /**
     * Add Activity Row
     */
    addActivityRow(activityName = '', params = {}) {
        const container = document.getElementById('activitiesContainer');
        if (!container) return;
        
        const activityId = `activity-${Date.now()}-${Math.random()}`;
        const activityRow = document.createElement('div');
        activityRow.className = 'activity-row';
        activityRow.id = activityId;
        activityRow.innerHTML = `
            <div class="activity-header">
                <input type="text" class="activity-name" placeholder="Activity Name (e.g., Booking_Created)" value="${activityName}">
                <button class="btn-remove-activity" data-activity-id="${activityId}">Remove Activity</button>
            </div>
            <div class="activity-params-container" data-activity-id="${activityId}"></div>
            <button class="btn-add-activity-param" data-activity-id="${activityId}">+ Add Parameter</button>
        `;

        container.appendChild(activityRow);

        activityRow.querySelector('.activity-name').addEventListener('change', () => this.saveFormState());

        activityRow.querySelector('.btn-remove-activity').addEventListener('click', (e) => {
            document.getElementById(e.target.dataset.activityId).remove();
            this.saveFormState();
        });

        activityRow.querySelector('.btn-add-activity-param').addEventListener('click', (e) => {
            this.addActivityParamRow(e.target.dataset.activityId);
        });

        if (Object.keys(params).length > 0) {
            Object.entries(params).forEach(([key, param]) => {
                const arrayItems = param.arrayItems || [];
                this.addActivityParamRow(activityId, key, param.value, param.dataType, arrayItems);
            });
        }

        return activityId;
    }

    /**
     * Add Activity Parameter Row
     */
    addActivityParamRow(activityId, key = '', value = '', dataType = DATA_TYPES.string, arrayItems = []) {
        const container = document.querySelector(`.activity-params-container[data-activity-id="${activityId}"]`);
        if (!container) return;
        
        const paramId = `param-${Date.now()}-${Math.random()}`;
        const paramRow = document.createElement('div');
        paramRow.className = 'activity-param-row';
        paramRow.id = paramId;
        paramRow.innerHTML = `
            <div class="param-inputs">
                <input type="text" class="param-key" placeholder="Parameter Name" value="${key}">
                <input type="text" class="param-value" placeholder="Value (or use Array Builder for arrays) Leave Empty for appending default values" value="${value}" ${dataType === DATA_TYPES.array ? 'disabled' : ''} style="background-color: ${dataType === DATA_TYPES.array ? '#e0e0e0' : 'white'};">
                <select class="param-type">
                    <option value="${DATA_TYPES.string}" ${dataType === DATA_TYPES.string ? 'selected' : ''}>String</option>
                    <option value="${DATA_TYPES.float}" ${dataType === DATA_TYPES.float ? 'selected' : ''}>Float</option>
                    <option value="${DATA_TYPES.number}" ${dataType === DATA_TYPES.number ? 'selected' : ''}>Number</option>
                    <option value="${DATA_TYPES.date}" ${dataType === DATA_TYPES.date ? 'selected' : ''}>Date</option>
                    <option value="${DATA_TYPES.array}" ${dataType === DATA_TYPES.array ? 'selected' : ''}>Array (JSON)</option>
                </select>
                <button class="btn-array-builder" data-param-id="${paramId}" style="display: ${dataType === DATA_TYPES.array ? 'inline-block' : 'none'};">Array Builder</button>
                <button class="btn-remove-param" data-param-id="${paramId}">Remove</button>
            </div>
            <div class="array-items-container" id="array-items-${paramId}" style="display: ${dataType === DATA_TYPES.array ? 'block' : 'none'}; margin-left: 20px; margin-top: 10px;"></div>
        `;

        container.appendChild(paramRow);

        const typeSelect = paramRow.querySelector('.param-type');
        const valueInput = paramRow.querySelector('.param-value');
        const keyInput = paramRow.querySelector('.param-key');
        const arrayBuilderBtn = paramRow.querySelector('.btn-array-builder');
        const arrayItemsContainer = document.getElementById(`array-items-${paramId}`);

        // Add change listeners for persistence and defaults
        keyInput.addEventListener('change', () => this.saveFormState());
        
        valueInput.addEventListener('change', () => this.saveFormState());
        valueInput.addEventListener('blur', () => {
            if (!valueInput.value && typeSelect.value !== DATA_TYPES.array) {
                valueInput.value = this.getDefaultValue(typeSelect.value, true);
                this.saveFormState();
            }
        });

        typeSelect.addEventListener('change', (e) => {
            const isArray = e.target.value === DATA_TYPES.array;
            valueInput.disabled = isArray;
            valueInput.style.backgroundColor = isArray ? '#e0e0e0' : 'white';
            arrayBuilderBtn.style.display = isArray ? 'inline-block' : 'none';
            arrayItemsContainer.style.display = isArray ? 'block' : 'none';
            
            if (!valueInput.value && !isArray) {
                valueInput.value = this.getDefaultValue(e.target.value, true);
            }
            this.saveFormState();
        });

        arrayBuilderBtn.addEventListener('click', () => {
            this.toggleArrayBuilder(paramId, arrayItemsContainer);
        });

        paramRow.querySelector('.btn-remove-param').addEventListener('click', (e) => {
            document.getElementById(e.target.dataset.paramId).remove();
            this.saveFormState();
        });

        if (arrayItems && arrayItems.length > 0) {
            arrayItems.forEach((item, idx) => {
                this.addArrayItemRow(paramId, arrayItemsContainer, idx, item);
            });
        }
    }

    /**
     * Toggle Array Builder visibility
     */
    toggleArrayBuilder(paramId, container) {
        const builderSection = container.querySelector('.array-builder-section');
        
        if (builderSection) {
            builderSection.style.display = builderSection.style.display === 'none' ? 'block' : 'none';
        } else {
            const builder = document.createElement('div');
            builder.className = 'array-builder-section';
            builder.innerHTML = `
                <div style="margin: 10px 0;">
                    <label style="display: block; margin-bottom: 5px; font-weight: bold;">Array Items</label>
                    <div class="array-items-list" id="items-list-${paramId}"></div>
                    <button class="btn btn-secondary" data-param-id="${paramId}" style="margin-top: 10px;">+ Add Array Item</button>
                </div>
            `;
            container.appendChild(builder);
            
            builder.querySelector('button').addEventListener('click', (e) => {
                e.preventDefault();
                this.addArrayItemRow(paramId, document.getElementById(`items-list-${paramId}`));
            });
        }
    }

    /**
     * Add Array Item
     */
    addArrayItemRow(paramId, container, itemIndex = null, itemData = {}) {
        const itemId = `array-item-${paramId}-${Date.now()}-${Math.random()}`;
        const itemNum = container.querySelectorAll('.array-item-row').length + 1;

        const itemRow = document.createElement('div');
        itemRow.className = 'array-item-row';
        itemRow.id = itemId;
        itemRow.style.border = '1px solid #ddd';
        itemRow.style.padding = '10px';
        itemRow.style.margin = '10px 0';
        itemRow.style.borderRadius = '4px';
        itemRow.style.backgroundColor = '#f9f9f9';
        itemRow.innerHTML = `
            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                <strong>Item #${itemNum}</strong>
                <button class="btn-remove-item" data-item-id="${itemId}" style="padding: 2px 8px; font-size: 12px;">Remove Item</button>
            </div>
            <div class="array-item-fields" data-param-id="${paramId}"></div>
            <button class="btn-add-field" data-item-id="${itemId}" style="margin-top: 8px; padding: 4px 8px; font-size: 12px;">+ Add Field</button>
        `;

        container.appendChild(itemRow);

        const fieldsContainer = itemRow.querySelector('.array-item-fields');
        itemRow.querySelector('.btn-remove-item').addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById(e.target.dataset.itemId).remove();
            this.saveFormState();
        });

        itemRow.querySelector('.btn-add-field').addEventListener('click', (e) => {
            e.preventDefault();
            this.addArrayFieldRow(itemId, fieldsContainer);
        });

        if (Object.keys(itemData).length > 0) {
            Object.entries(itemData).forEach(([fieldKey, fieldData]) => {
                const fieldValue = typeof fieldData === 'object' ? fieldData.value : fieldData;
                const fieldType = typeof fieldData === 'object' ? fieldData.type : DATA_TYPES.string;
                this.addArrayFieldRow(itemId, fieldsContainer, fieldKey, fieldValue, fieldType);
            });
        }
    }

    /**
     * Add Field to Array Item
     */
    addArrayFieldRow(itemId, container, fieldKey = '', fieldValue = '', fieldType = DATA_TYPES.string) {
        const fieldId = `field-${itemId}-${Date.now()}`;
        const fieldRow = document.createElement('div');
        fieldRow.className = 'array-field-row';
        fieldRow.id = fieldId;
        fieldRow.style.display = 'flex';
        fieldRow.style.gap = '8px';
        fieldRow.style.marginBottom = '8px';
        fieldRow.style.alignItems = 'center';
        fieldRow.innerHTML = `
            <input type="text" class="field-key" placeholder="Field Name" value="${fieldKey}" style="flex: 1.2; padding: 8px; border: 1px solid #ddd; border-radius: 3px; min-width: 120px;">
            <input type="text" class="field-value" placeholder="Value" value="${fieldValue}" style="flex: 1.5; padding: 8px; border: 1px solid #ddd; border-radius: 3px; min-width: 150px;">
            <select class="field-type" style="flex: 0.8; padding: 8px; border: 1px solid #ddd; border-radius: 3px; min-width: 80px;">
                <option value="${DATA_TYPES.string}" ${fieldType === DATA_TYPES.string ? 'selected' : ''}>String</option>
                <option value="${DATA_TYPES.float}" ${fieldType === DATA_TYPES.float ? 'selected' : ''}>Float</option>
                <option value="${DATA_TYPES.number}" ${fieldType === DATA_TYPES.number ? 'selected' : ''}>Number</option>
                <option value="${DATA_TYPES.date}" ${fieldType === DATA_TYPES.date ? 'selected' : ''}>Date</option>
            </select>
            <button class="btn-remove-field" data-field-id="${fieldId}" style="padding: 6px 10px; font-size: 12px; background-color: #ff6b6b; color: white; border: none; border-radius: 3px; cursor: pointer; flex-shrink: 0;">×</button>
        `;

        container.appendChild(fieldRow);

        const typeSelect = fieldRow.querySelector('.field-type');
        const valueInput = fieldRow.querySelector('.field-value');

        // Add change listeners for persistence and defaults
        fieldRow.querySelector('.field-key').addEventListener('change', () => this.saveFormState());
        
        valueInput.addEventListener('change', () => this.saveFormState());
        valueInput.addEventListener('blur', () => {
            if (!valueInput.value) {
                valueInput.value = this.getDefaultValue(typeSelect.value, true);
                this.saveFormState();
            }
        });

        typeSelect.addEventListener('change', () => {
            if (!valueInput.value) {
                valueInput.value = this.getDefaultValue(typeSelect.value, true);
            }
            this.saveFormState();
        });

        fieldRow.querySelector('.btn-remove-field').addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById(e.target.dataset.fieldId).remove();
            this.saveFormState();
        });
    }

    /**
     * Get all activities with their parameters
     */
    getActivities() {
        const activities = [];
        document.querySelectorAll('.activity-row').forEach(actRow => {
            const activityName = actRow.querySelector('.activity-name').value.trim();
            if (!activityName) return;

            const params = {};
            actRow.querySelectorAll('.activity-param-row').forEach(paramRow => {
                const key = paramRow.querySelector('.param-key').value.trim();
                const value = paramRow.querySelector('.param-value').value.trim();
                const dataType = paramRow.querySelector('.param-type').value;

                if (key) {
                    if (dataType === DATA_TYPES.array) {
                        const arrayItems = [];
                        const itemsContainer = paramRow.querySelector('.array-items-container');
                        
                        if (itemsContainer) {
                            itemsContainer.querySelectorAll('.array-item-row').forEach(itemRow => {
                                const itemObj = {};
                                itemRow.querySelectorAll('.array-field-row').forEach(fieldRow => {
                                    const fieldKey = fieldRow.querySelector('.field-key').value.trim();
                                    const fieldValue = fieldRow.querySelector('.field-value').value.trim();
                                    const fieldType = fieldRow.querySelector('.field-type')?.value || DATA_TYPES.string;
                                    if (fieldKey && fieldValue) {
                                        try {
                                            itemObj[fieldKey] = this.formatActivityValue(fieldValue, fieldType, false);
                                        } catch (e) {
                                            itemObj[fieldKey] = fieldValue;
                                        }
                                    }
                                });
                                if (Object.keys(itemObj).length > 0) {
                                    arrayItems.push(itemObj);
                                }
                            });
                        }
                        
                        if (arrayItems.length === 0 && value) {
                            try {
                                const parsed = JSON.parse(value);
                                if (Array.isArray(parsed)) {
                                    params[key] = parsed;
                                }
                            } catch (e) {
                                throw new Error(`Activity "${activityName}", array "${key}": Invalid JSON array format`);
                            }
                        } else if (arrayItems.length > 0) {
                            params[key] = arrayItems;
                        }
                    } else if (value) {
                        try {
                            const formattedValue = this.formatActivityValue(value, dataType, false);
                            params[key] = formattedValue;
                        } catch (error) {
                            throw new Error(`Activity "${activityName}", parameter "${key}": ${error.message}`);
                        }
                    }
                }
            });

            activities.push({
                activity_name: activityName,
                activity_params: params
            });
        });
        return activities;
    }

    /**
     * Format activity parameter value based on type
     */
    formatActivityValue(value, dataType, isArrayName = false) {
        if (!value) return null;

        switch (dataType) {
            case DATA_TYPES.string:
                return value;
            case DATA_TYPES.float:
                return parseFloat(value);
            case DATA_TYPES.number:
                return parseInt(value, 10);
            case DATA_TYPES.date:
                if (!/^(\d{4}-\d{2}-\d{2}|\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})/.test(value)) {
                    throw new Error(`Invalid date format. Use YYYY-MM-DD or YYYY-MM-DD HH:MM:SS`);
                }
                return value;
            case DATA_TYPES.array:
                try {
                    const parsed = JSON.parse(value);
                    if (!Array.isArray(parsed)) {
                        throw new Error('Must be a valid JSON array');
                    }
                    return parsed;
                } catch (e) {
                    throw new Error(`Invalid JSON array: ${e.message}`);
                }
            default:
                return value;
        }
    }

    /**
     * Toggle Activity API Key visibility
     */
    toggleActivityApiKeyVisibility() {
        const apiKeyInput = document.getElementById('activityApiKey');
        const toggleBtn = document.getElementById('toggleActivityApiKey');

        if (!apiKeyInput || !toggleBtn) return;

        if (apiKeyInput.type === 'password') {
            apiKeyInput.type = 'text';
            toggleBtn.textContent = 'Hide';
        } else {
            apiKeyInput.type = 'password';
            toggleBtn.textContent = 'Show';
        }
    }

    /**
     * Handle CSV File Upload
     */
    handleCSVUpload() {
        const fileInput = document.getElementById('csvFileInput');
        const statusMessage = document.getElementById('statusMessage');

        if (!fileInput.files || fileInput.files.length === 0) {
            Utils.showStatus(statusMessage, 'Please select a CSV file', 'error', 4000);
            return;
        }

        const file = fileInput.files[0];
        const reader = new FileReader();

        reader.onload = (e) => {
            try {
                const csvContent = e.target.result;
                const parsedActivities = CSVParser.parseCSV(csvContent);

                if (parsedActivities.length === 0) {
                    Utils.showStatus(statusMessage, 'No valid activities found in CSV', 'error', 4000);
                    return;
                }

                // Show preview in a tabular format
                this.showCSVPreview(parsedActivities, fileInput, statusMessage);
            } catch (error) {
                Utils.showStatus(statusMessage, `CSV Parse Error: ${error.message}`, 'error', 5000);
            }
        };

        reader.onerror = () => {
            Utils.showStatus(statusMessage, 'Error reading file', 'error', 4000);
        };

        reader.readAsText(file);
    }

    /**
     * Show CSV Preview in Table Format
     */
    showCSVPreview(parsedActivities, fileInput, statusMessage) {
        let previewContainer = document.getElementById('csvPreviewContainer');
        
        if (!previewContainer) {
            previewContainer = document.createElement('div');
            previewContainer.id = 'csvPreviewContainer';
            const uploadSection = document.querySelector('.csv-upload-section');
            uploadSection.appendChild(previewContainer);
        }

        // Build table rows from parsed activities
        let tableRows = '';
        
        // Build table rows with activity grouping
        parsedActivities.forEach((activity, actIndex) => {
            const params = activity.params;
            const paramKeys = Object.keys(params);
            
            paramKeys.forEach((paramKey, paramIndex) => {
                const param = params[paramKey];
                const isArrayType = Array.isArray(param.arrayItems);
                const typeLabel = isArrayType ? 'Array' : this.getDataTypeLabel(param.dataType);
                const sampleValue = isArrayType ? 
                    `[${param.arrayItems.length} item${param.arrayItems.length !== 1 ? 's' : ''}]` : 
                    String(param.value);

                const typeClass = typeLabel.toLowerCase().replace(/\\s+/g, '');
                tableRows += `
                    <tr>
                        ${paramIndex === 0 ? `<td rowspan=\"${paramKeys.length}\" style=\"font-weight: 600; background-color: #f0f0f0; vertical-align: top;\">${activity.name}</td>` : ''}
                        <td><strong>${paramKey}</strong></td>
                        <td><span class="csv-param-type ${typeClass}">${typeLabel}</span></td>
                        <td title="${sampleValue}">${this.truncateText(sampleValue, 30)}</td>
                    </tr>
                `;
            });
        });

        previewContainer.innerHTML = `
            <div class="csv-preview-container">
                <div class="csv-preview-header">📊 CSV Preview - ${parsedActivities.length} Activities</div>
                <table class="csv-preview-table">
                    <thead>
                        <tr>
                            <th style="width: 25%;">Activity</th>
                            <th style="width: 25%;">Parameter</th>
                            <th style="width: 20%;">Type</th>
                            <th style="width: 30%;">Sample Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${tableRows}
                    </tbody>
                </table>
                <div class="csv-preview-actions">
                    <button class="btn-apply-csv" id="applyCSVBtn">✓ Apply & Load Activities</button>
                    <button class="btn-cancel-csv" id="cancelCSVBtn">✕ Cancel</button>
                </div>
            </div>
        `;

        // Store parsed activities for later use
        this._csvData = { activities: parsedActivities, fileInput, statusMessage };

        document.getElementById('applyCSVBtn').addEventListener('click', () => {
            this.applyCSVData(parsedActivities, fileInput, statusMessage);
        });

        document.getElementById('cancelCSVBtn').addEventListener('click', () => {
            previewContainer.innerHTML = '';
            fileInput.value = '';
        });
    }

    /**
     * Apply CSV Data to Form
     */
    applyCSVData(parsedActivities, fileInput, statusMessage) {
        try {
            // Clear existing activities
            document.getElementById('activitiesContainer').innerHTML = '';

            // Add parsed activities to form
            parsedActivities.forEach(activity => {
                this.addActivityRow(activity.name, activity.params);
            });

            // Save form state
            this.saveFormState();

            // Clear preview
            const previewContainer = document.getElementById('csvPreviewContainer');
            previewContainer.innerHTML = '';

            Utils.showStatus(statusMessage, `✓ Successfully loaded ${parsedActivities.length} activities from CSV`, 'success', 4000);
            
            // Clear file input
            fileInput.value = '';
        } catch (error) {
            Utils.showStatus(statusMessage, `Error loading activities: ${error.message}`, 'error', 5000);
        }
    }

    /**
     * Get readable label for data type
     */
    getDataTypeLabel(dataType) {
        const labels = {
            [DATA_TYPES.string]: 'String',
            [DATA_TYPES.number]: 'Number',
            [DATA_TYPES.float]: 'Float',
            [DATA_TYPES.date]: 'Date',
            [DATA_TYPES.array]: 'Array'
        };
        return labels[dataType] || 'String';
    }

    /**
     * Truncate text for display
     */
    truncateText(text, length) {
        const str = String(text);
        return str.length > length ? str.substring(0, length) + '...' : str;
    }

    /**
     * Handle Generate Activity cURL
     */
    handleGenerateActivityCurl() {
        const statusMessage = document.getElementById('statusMessage');

        try {
            const bearerToken = document.getElementById('activityApiKey').value.trim();
            const region = document.getElementById('activityRegion').value;
            const assetId = document.getElementById('assetId').value.trim();
            const identity = document.getElementById('identity').value.trim();
            const activitySource = document.getElementById('activitySource').value;

            const errors = [];
            if (!bearerToken) errors.push('Bearer token is required');
            if (!region) errors.push('Region is required');
            if (!assetId) errors.push('Asset ID is required');
            if (!identity) errors.push('Identity is required');
            if (!activitySource) errors.push('Activity source is required');

            if (errors.length > 0) {
                Utils.showStatus(statusMessage, errors.join(', '), 'error', 4000);
                return;
            }

            const activities = this.getActivities();
            if (activities.length === 0) {
                Utils.showStatus(statusMessage, 'At least one activity with a name is required', 'error', 4000);
                return;
            }

            const payload = APIHandler.buildActivityPayload(assetId, identity, activitySource, activities);
            const curl = APIHandler.generateActivityCurl(bearerToken, region, payload);

            this.displayCurl(curl);
            Utils.showStatus(statusMessage, 'Activity API cURL generated successfully!', 'success');
        } catch (error) {
            Utils.showStatus(statusMessage, `Error: ${error.message}`, 'error', 4000);
        }
    }

    /**
     * Handle Trigger Activity API
     */
    async handleTriggerActivityAPI() {
        const statusMessage = document.getElementById('statusMessage');

        try {
            const bearerToken = document.getElementById('activityApiKey').value.trim();
            const region = document.getElementById('activityRegion').value;
            const assetId = document.getElementById('assetId').value.trim();
            const identity = document.getElementById('identity').value.trim();
            const activitySource = document.getElementById('activitySource').value;

            const errors = [];
            if (!bearerToken) errors.push('Bearer token is required');
            if (!region) errors.push('Region is required');
            if (!assetId) errors.push('Asset ID is required');
            if (!identity) errors.push('Identity is required');
            if (!activitySource) errors.push('Activity source is required');

            if (errors.length > 0) {
                Utils.showStatus(statusMessage, errors.join(', '), 'error', 4000);
                return;
            }

            const activities = this.getActivities();
            if (activities.length === 0) {
                Utils.showStatus(statusMessage, 'At least one activity with a name is required', 'error', 4000);
                return;
            }

            const payload = APIHandler.buildActivityPayload(assetId, identity, activitySource, activities);

            Utils.showStatus(statusMessage, 'Triggering Activity API...', 'info');

            const response = await APIHandler.triggerActivityAPI(bearerToken, region, payload);
            const formattedResponse = APIHandler.formatResponse(response);

            // Store the exact request data for history restoration
            const historyPayload = JSON.parse(JSON.stringify(payload)); // Deep copy to preserve exact state
            
            // Get the complete form data to store (same structure as activityFormData)
            const completeActivityData = this.getActivityFormData();

            // Add to history with apiType='activity' and full activity details
            this.addToHistory({
                apiType: 'activity',
                region: region,
                apiKey: bearerToken, // Save Bearer Token (mapped to apiKey)
                activity: `Events Count (${activities.length})`,
                listId: assetId,
                identity: identity,
                activitySource: activitySource,
                activities: completeActivityData.activities,
                historyPayload: historyPayload,
                attributes: activities.map(a => a.activity_name),
                response: formattedResponse.body,
                status: formattedResponse.status
            });
            this.displayResponse(formattedResponse);
            Utils.showStatus(statusMessage, 'Activity API triggered successfully!', 'success');
        } catch (error) {
            Utils.showStatus(statusMessage, `Error: ${error.message}`, 'error', 4000);
        }
    }

    /**
     * Handle Clear Contact Form
     */
    handleClearContactForm() {
        const statusMessage = document.getElementById('statusMessage');
        
        // Show confirmation dialog
        const confirmed = confirm('Are you sure you want to clear the contact form? This action cannot be undone.');
        if (!confirmed) {
            return;
        }

        try {
            // Clear form fields
            document.getElementById('region').value = '';
            document.getElementById('apiKey').value = '';
            document.getElementById('activity').value = '';
            document.getElementById('listId').value = '';
            
            // Clear Primary Key fields
            document.getElementById('primaryKey').value = '';
            document.getElementById('primaryValue').value = '';
            document.getElementById('primaryType').value = 'string';

            // Clear dynamic attributes
            document.getElementById('attributesContainer').innerHTML = '';
            
            // Save form state (empty)
            this.saveFormState();
            
            Utils.showStatus(statusMessage, '✓ Contact form cleared successfully', 'success', 3000);
        } catch (error) {
            Utils.showStatus(statusMessage, `Error clearing form: ${error.message}`, 'error', 4000);
        }
    }

    /**
     * Handle Clear Activity Form
     */
    handleClearActivityForm() {
        const statusMessage = document.getElementById('statusMessage');
        
        // Show confirmation dialog
        const confirmed = confirm('Are you sure you want to clear all activities? This action cannot be undone.');
        if (!confirmed) {
            return;
        }

        try {
            // Clear all activities
            document.getElementById('activitiesContainer').innerHTML = '';
            
            // Clear CSV preview if any
            const csvPreviewContainer = document.getElementById('csvPreviewContainer');
            if (csvPreviewContainer) {
                csvPreviewContainer.innerHTML = '';
            }
            
            // Clear file input
            const csvFileInput = document.getElementById('csvFileInput');
            if (csvFileInput) {
                csvFileInput.value = '';
            }
            
            // Save form state (empty)
            this.saveFormState();
            
            Utils.showStatus(statusMessage, '✓ Form cleared successfully', 'success', 3000);
        } catch (error) {
            Utils.showStatus(statusMessage, `Error clearing form: ${error.message}`, 'error', 4000);
        }
    }

    /**
     * Add a new attribute row
     */
    addAttributeRow(key = '', value = '', dataType = DATA_TYPES.string) {
        const container = document.getElementById('attributesContainer');
        const rowId = `attr-${this.attributeCounter++}`;

        const attributeRow = document.createElement('div');
        attributeRow.className = 'attribute-row';
        attributeRow.id = rowId;
        attributeRow.innerHTML = `
            <div class="attribute-inputs">
                <input type="text" class="attr-key" placeholder="Key (e.g., EMAIL/MOBILE)" value="${key}">
                <input type="text" class="attr-value" placeholder="Value" value="${value}">
                <select class="attr-type">
                    <option value="${DATA_TYPES.string}" ${dataType === DATA_TYPES.string ? 'selected' : ''}>String</option>
                    <option value="${DATA_TYPES.float}" ${dataType === DATA_TYPES.float ? 'selected' : ''}>Float</option>
                    <option value="${DATA_TYPES.number}" ${dataType === DATA_TYPES.number ? 'selected' : ''}>Number</option>
                    <option value="${DATA_TYPES.date}" ${dataType === DATA_TYPES.date ? 'selected' : ''}>Date (YYYY-MM-DD)</option>
                </select>
                <button class="btn-remove" data-row-id="${rowId}">Remove</button>
            </div>
        `;

        container.appendChild(attributeRow);

        const typeSelect = attributeRow.querySelector('.attr-type');
        const valueInput = attributeRow.querySelector('.attr-value');

        // Add change listeners for persistence and defaults
        attributeRow.querySelector('.attr-key').addEventListener('change', () => this.saveFormState());
        
        valueInput.addEventListener('change', () => this.saveFormState());
        valueInput.addEventListener('blur', () => {
            if (!valueInput.value) {
                valueInput.value = this.getDefaultValue(typeSelect.value, false);
                this.saveFormState();
            }
        });

        typeSelect.addEventListener('change', () => {
            if (!valueInput.value) {
                valueInput.value = this.getDefaultValue(typeSelect.value, false);
            }
            this.saveFormState();
        });

        attributeRow.querySelector('.btn-remove').addEventListener('click', (e) => {
            document.getElementById(e.target.dataset.rowId).remove();
            this.saveFormState();
        });
    }

    /**
     * Get all form data
     */
    getFormData() {
        const region = document.getElementById('region').value;
        const apiKey = document.getElementById('apiKey').value;
        const activity = document.getElementById('activity').value;
        const listId = document.getElementById('listId').value;

        // Get Primary Key
        const primaryKey = document.getElementById('primaryKey').value.trim();
        const primaryValue = document.getElementById('primaryValue').value.trim();
        const primaryType = document.getElementById('primaryType').value;

        const attributes = [];
        document.querySelectorAll('#attributesContainer .attribute-row').forEach(row => {
            const key = row.querySelector('.attr-key').value.trim();
            const value = row.querySelector('.attr-value').value.trim();
            const dataType = row.querySelector('.attr-type').value;

            if (key && value) {
                attributes.push({ key, value, dataType });
            }
        });

        return {
            region,
            apiKey,
            activity,
            listId: listId || null,
            primaryKey: { key: primaryKey, value: primaryValue, dataType: primaryType },
            attributes
        };
    }

    /**
     * Handle Contact Preview
     */
    handleContactPreview() {
        const formData = this.getFormData();
        const attributes = [];

        // Add Primary Key
        if (formData.primaryKey && formData.primaryKey.key) {
            attributes.push({
                key: formData.primaryKey.key,
                value: formData.primaryKey.value,
                dataType: formData.primaryKey.dataType,
                isPrimary: true
            });
        }

        // Add other attributes
        if (formData.attributes && formData.attributes.length > 0) {
            attributes.push(...formData.attributes);
        }

        if (attributes.length === 0) {
            Utils.showStatus(document.getElementById('statusMessage'), 'No attributes to preview', 'warning', 3000);
            return;
        }

        let tableHtml = `
            <table style="width: 100%; border-collapse: collapse; margin-top: 10px; table-layout: fixed;">
                <thead>
                    <tr style="background-color: #f2f2f2;">
                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left; width: 35%;">Attribute Name</th>
                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left; width: 25%;">Data Type</th>
                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left; width: 40%;">Value</th>
                    </tr>
                </thead>
                <tbody>
        `;

        attributes.forEach(attr => {
            const rowStyle = attr.isPrimary ? 'background-color: #e8f4f8;' : '';
            const keyDisplay = attr.isPrimary ? `<strong>${attr.key} (PK)</strong>` : attr.key;
            
            tableHtml += `
                <tr style="${rowStyle}">
                    <td style="border: 1px solid #ddd; padding: 8px; word-break: break-all;">${keyDisplay}</td>
                    <td style="border: 1px solid #ddd; padding: 8px;">${attr.dataType}</td>
                    <td style="border: 1px solid #ddd; padding: 8px; word-break: break-all;">${attr.value}</td>
                </tr>
            `;
        });

        tableHtml += `
                </tbody>
            </table>
        `;

        this.showPreviewModal('Contact Attributes Preview', tableHtml);
    }

    /**
     * Handle Activity Preview
     */
    handleActivityPreview() {
        const activityData = this.getActivityFormData();
        
        if (!activityData || !activityData.activities || activityData.activities.length === 0) {
            Utils.showStatus(document.getElementById('statusMessage'), 'No activities to preview', 'warning', 3000);
            return;
        }

        let tableHtml = `
            <table style="width: 100%; border-collapse: collapse; margin-top: 10px; table-layout: fixed;">
                <thead>
                    <tr style="background-color: #f2f2f2;">
                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left; width: 25%;">Event</th>
                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left; width: 25%;">Param</th>
                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left; width: 15%;">Type</th>
                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left; width: 35%;">Value</th>
                    </tr>
                </thead>
                <tbody>
        `;

        activityData.activities.forEach(activity => {
            const params = activity.params;
            const paramKeys = Object.keys(params);
            
            if (paramKeys.length === 0) {
                tableHtml += `
                    <tr>
                        <td style="border: 1px solid #ddd; padding: 8px; word-break: break-all;"><strong>${activity.name}</strong></td>
                        <td style="border: 1px solid #ddd; padding: 8px;" colspan="3"><em>No parameters</em></td>
                    </tr>
                `;
            } else {
                paramKeys.forEach((key, index) => {
                    const param = params[key];
                    let valueDisplay = param.value;
                    
                    if (param.dataType === DATA_TYPES.array) {
                        valueDisplay = `<pre style="margin: 0; font-size: 11px; max-height: 100px; overflow: auto;">${JSON.stringify(param.arrayItems, null, 2)}</pre>`;
                    }

                    tableHtml += `
                        <tr>
                            <td style="border: 1px solid #ddd; padding: 8px; word-break: break-all;">${index === 0 ? `<strong>${activity.name}</strong>` : ''}</td>
                            <td style="border: 1px solid #ddd; padding: 8px; word-break: break-all;">${key}</td>
                            <td style="border: 1px solid #ddd; padding: 8px;">${param.dataType}</td>
                            <td style="border: 1px solid #ddd; padding: 8px; word-break: break-word;">${valueDisplay}</td>
                        </tr>
                    `;
                });
            }
        });

        tableHtml += `
                </tbody>
            </table>
        `;

        this.showPreviewModal('Activity Events Preview', tableHtml);
    }

    /**
     * Show Preview Modal
     */
    showPreviewModal(title, content) {
        const modal = document.getElementById('previewModal');
        const titleEl = document.getElementById('previewTitle');
        const bodyEl = document.getElementById('previewBody');
        
        if (modal && titleEl && bodyEl) {
            titleEl.textContent = title;
            bodyEl.innerHTML = content;
            modal.style.display = 'block';
            modal.classList.remove('hidden');
        }
    }

    /**
     * Close Preview Modal
     */
    closePreviewModal() {
        const modal = document.getElementById('previewModal');
        if (modal) {
            modal.style.display = 'none';
            modal.classList.add('hidden');
        }
    }

    /**
     * Handle Generate cURL
     */
    handleGenerateCurl() {
        const statusMessage = document.getElementById('statusMessage');

        try {
            const formData = this.getFormData();
            const errors = Utils.validateFormData(formData);

            if (errors.length > 0) {
                Utils.showStatus(statusMessage, errors.join(', '), 'error', 4000);
                return;
            }

            const endpoint = ENDPOINTS[formData.region];
            const queryParams = APIHandler.buildQueryParams(formData.apiKey, formData.activity, formData.listId);
            
            // Combine primary key and attributes
            const allAttributes = [];
            if (formData.primaryKey && formData.primaryKey.key && formData.primaryKey.value) {
                allAttributes.push(formData.primaryKey);
            }
            allAttributes.push(...formData.attributes);

            const bodyParams = APIHandler.buildRequestBody(allAttributes);

            const curl = APIHandler.generateCurl(endpoint, queryParams, bodyParams);

            this.displayCurl(curl);
            Utils.showStatus(statusMessage, 'cURL generated successfully!', 'success');
        } catch (error) {
            Utils.showStatus(statusMessage, `Error: ${error.message}`, 'error', 4000);
        }
    }

    /**
     * Display cURL output
     */
    displayCurl(curl) {
        const curlSection = document.getElementById('curlSection');
        const curlOutput = document.getElementById('curlOutput');

        curlOutput.value = curl;
        curlSection.classList.remove('hidden');
        curlSection.scrollIntoView({ behavior: 'smooth' });
    }

    /**
     * Close cURL section
     */
    closeCurlSection() {
        document.getElementById('curlSection').classList.add('hidden');
    }

    /**
     * Handle Trigger API
     */
    async handleTriggerAPI() {
        const statusMessage = document.getElementById('statusMessage');

        try {
            const formData = this.getFormData();
            const errors = Utils.validateFormData(formData);

            if (errors.length > 0) {
                Utils.showStatus(statusMessage, errors.join(', '), 'error', 4000);
                return;
            }

            const endpoint = ENDPOINTS[formData.region];
            const queryParams = APIHandler.buildQueryParams(formData.apiKey, formData.activity, formData.listId);
            
            // Combine primary key and attributes
            const allAttributes = [];
            if (formData.primaryKey && formData.primaryKey.key && formData.primaryKey.value) {
                allAttributes.push(formData.primaryKey);
            }
            allAttributes.push(...formData.attributes);

            const bodyParams = APIHandler.buildRequestBody(allAttributes);

            Utils.showStatus(statusMessage, 'Triggering API...', 'info');

            const response = await APIHandler.triggerAPI(endpoint, queryParams, bodyParams);
            const formattedResponse = APIHandler.formatResponse(response);

            // Save to history with apiType='contact'
            this.addToHistory({
                apiType: 'contact',
                region: formData.region,
                apiKey: formData.apiKey, // Save API Key
                activity: formData.activity,
                listId: formData.listId,
                attributes: allAttributes,
                response: formattedResponse.body,
                status: formattedResponse.status
            });

            this.displayResponse(formattedResponse);
            Utils.showStatus(statusMessage, 'API triggered successfully!', 'success');
        } catch (error) {
            Utils.showStatus(statusMessage, `Error: ${error.message}`, 'error', 4000);
        }
    }

    /**
     * Display API response
     */
    displayResponse(response) {
        const responseSection = document.getElementById('responseSection');
        const responseContent = document.getElementById('responseContent');

        const statusClass = response.status >= 200 && response.status < 300 ? 'success' : 'error';

        responseContent.innerHTML = `
            <div class="response-status ${statusClass}">
                <strong>Status:</strong> ${response.status} ${response.statusText}
            </div>
            <div class="response-body">
                <pre>${Utils.formatJSON(response.body)}</pre>
            </div>
        `;

        responseSection.classList.remove('hidden');
    }

    /**
     * Handle Trigger cURL
     */
    async handleTriggerCurl() {
        const curlOutput = document.getElementById('curlOutput');
        const statusMessage = document.getElementById('statusMessage');
        const curlCommand = curlOutput.value.trim();

        if (!curlCommand) {
            Utils.showStatus(statusMessage, 'No cURL command to trigger', 'error', 3000);
            return;
        }

        try {
            Utils.showStatus(statusMessage, 'Parsing and triggering cURL...', 'info');
            
            // Basic cURL parsing logic
            let url = '';
            let bodyParams = {};
            let endpoint = '';
            let queryParams = {};

            // 1. Try parsing as Contact API (curl -X POST "...")
            const contactApiMatch = curlCommand.match(/curl -X POST "([^"]+)"/);
            
            if (contactApiMatch) {
                url = contactApiMatch[1];
                
                // Extract Data for Contact API
                // Check for --data-urlencode 'data=...'
                const dataUrlEncodeMatch = curlCommand.match(/--data-urlencode 'data=([^']+)'/);
                if (dataUrlEncodeMatch) {
                    bodyParams = { data: dataUrlEncodeMatch[1] };
                } else {
                    // Check for -d "..."
                    const dataMatch = curlCommand.match(/-d "([^"]+)"/);
                    if (dataMatch) {
                        const params = new URLSearchParams(dataMatch[1]);
                        for (const [key, value] of params.entries()) {
                            bodyParams[key] = value;
                        }
                    }
                }

                // Split URL into endpoint and query params
                const urlObj = new URL(url);
                endpoint = `${urlObj.origin}${urlObj.pathname}`;
                for (const [key, value] of urlObj.searchParams.entries()) {
                    queryParams[key] = value;
                }

                const response = await APIHandler.triggerAPI(endpoint, queryParams, bodyParams);
                const formattedResponse = APIHandler.formatResponse(response);
                this.displayResponse(formattedResponse);

            } else {
                // 2. Try parsing as Activity API (curl --location '...')
                const activityApiMatch = curlCommand.match(/curl --location '([^']+)'/);
                const v5ApiMatch = curlCommand.match(/curl --request POST/);
                
                if (activityApiMatch) {
                    endpoint = activityApiMatch[1];
                    
                    // Extract Bearer Token
                    const tokenMatch = curlCommand.match(/--header 'Authorization: Bearer ([^']+)'/);
                    const bearerToken = tokenMatch ? tokenMatch[1] : '';
                    
                    // Extract JSON Payload (--data '...')
                    // Note: This regex is simple and might fail if the JSON contains single quotes that aren't escaped
                    // A more robust parser would be needed for complex cases
                    const dataMatch = curlCommand.match(/--data '([\s\S]+)'/);
                    let payload = [];
                    
                    if (dataMatch) {
                        try {
                            payload = JSON.parse(dataMatch[1]);
                        } catch (e) {
                            throw new Error('Could not parse JSON payload from cURL');
                        }
                    }

                    // Determine region from endpoint
                    let region = 'us'; // default
                    if (endpoint.includes('apiin')) region = 'in';
                    if (endpoint.includes('apieu')) region = 'eu';

                    const response = await APIHandler.triggerActivityAPI(bearerToken, region, payload);
                    const formattedResponse = APIHandler.formatResponse(response);
                    this.displayResponse(formattedResponse);

                } else if (v5ApiMatch) {
                    // 3. Try parsing as V5 Contact API
                    const urlMatch = curlCommand.match(/--url\s+([^\s\\]+)/);
                    if (!urlMatch) {
                        throw new Error('Could not parse URL from V5 cURL');
                    }
                    endpoint = urlMatch[1];

                    const apiKeyMatch = curlCommand.match(/--header 'api-key: ([^']+)'/);
                    const apiKey = apiKeyMatch ? apiKeyMatch[1] : '';

                    let payload = {};
                    // Match data. Typically comes as --data '...' or --data-raw '...' at the end.
                    const dataMatch = curlCommand.match(/--data '([\s\S]+)'$/) || curlCommand.match(/--data-raw '([\s\S]+)'$/);
                    
                    if (dataMatch) {
                        try {
                            payload = JSON.parse(dataMatch[1]);
                        } catch (e) {
                             throw new Error('Invalid JSON payload in V5 cURL');
                        }
                    }

                    const response = await APIHandler.triggerV5API(endpoint, apiKey, payload);
                    const formattedResponse = APIHandler.formatResponse(response);
                    this.displayResponse(formattedResponse);

                } else {
                    throw new Error('Could not parse URL from cURL command. Ensure it matches the generated format.');
                }
            }
            
            Utils.showStatus(statusMessage, 'API triggered successfully from cURL!', 'success');

        } catch (error) {
            console.error('cURL Trigger Error:', error);
            Utils.showStatus(statusMessage, `Error triggering cURL: ${error.message}`, 'error', 5000);
        }
    }

    /**
     * Handle Copy cURL
     */
    handleCopyCurl() {
        const curlOutput = document.getElementById('curlOutput');
        Utils.copyToClipboard(curlOutput.value);
        Utils.showStatus(document.getElementById('statusMessage'), 'cURL copied to clipboard!', 'success');
    }

    /**
     * Handle Copy Response
     */
    handleCopyResponse() {
        const responseContent = document.getElementById('responseContent');
        const text = responseContent.innerText;
        Utils.copyToClipboard(text);
        Utils.showStatus(document.getElementById('statusMessage'), 'Response copied to clipboard!', 'success');
    }

    /**
     * Close response section
     */
    closeResponseSection() {
        document.getElementById('responseSection').classList.add('hidden');
    }

    /**
     * Toggle API key visibility
     */
    toggleApiKeyVisibility() {
        const apiKeyInput = document.getElementById('apiKey');
        const toggleBtn = document.getElementById('toggleApiKey');

        if (apiKeyInput.type === 'password') {
            apiKeyInput.type = 'text';
            toggleBtn.textContent = 'Hide';
        } else {
            apiKeyInput.type = 'password';
            toggleBtn.textContent = 'Show';
        }
    }

    /**
     * Save form state to local storage
     */
    saveFormState() {
        const formData = this.getFormData();
        const activityFormData = this.getActivityFormData();
        let v5FormData = null;
        try { v5FormData = this.getV5FormData(); } catch(e) {}
        const activeVersion = document.querySelector('.api-type-btn.active[data-version]')?.dataset.version || 'v2';
        
        chrome.storage.local.set({ 
            formData: formData, 
            activityFormData: activityFormData,
            v5FormData: v5FormData,
            activeContactVersion: activeVersion
        });
    }

    /**
     * Get Activity API form data
     */
    getActivityFormData() {
        const activities = [];
        
        const activitiesContainer = document.getElementById('activitiesContainer');
        if (!activitiesContainer) return null;
        
        activitiesContainer.querySelectorAll('.activity-row').forEach(actRow => {
            const activityName = actRow.querySelector('.activity-name').value.trim();
            if (!activityName) return;

            const params = {};
            actRow.querySelectorAll('.activity-param-row').forEach(paramRow => {
                const key = paramRow.querySelector('.param-key').value.trim();
                const value = paramRow.querySelector('.param-value').value.trim();
                const dataType = paramRow.querySelector('.param-type').value;

                if (key) {
                    const paramData = { value, dataType };
                    
                    if (dataType === DATA_TYPES.array) {
                        const arrayItems = [];
                        const itemsContainer = paramRow.querySelector('.array-items-container');
                        
                        if (itemsContainer) {
                            itemsContainer.querySelectorAll('.array-item-row').forEach(itemRow => {
                                const itemObj = {};
                                itemRow.querySelectorAll('.array-field-row').forEach(fieldRow => {
                                    const fieldKey = fieldRow.querySelector('.field-key').value.trim();
                                    const fieldValue = fieldRow.querySelector('.field-value').value.trim();
                                    const fieldType = fieldRow.querySelector('.field-type')?.value || DATA_TYPES.string;
                                    if (fieldKey && fieldValue) {
                                        itemObj[fieldKey] = { value: fieldValue, type: fieldType };
                                    }
                                });
                                if (Object.keys(itemObj).length > 0) {
                                    arrayItems.push(itemObj);
                                }
                            });
                        }
                        paramData.arrayItems = arrayItems;
                    }
                    
                    params[key] = paramData;
                }
            });

            activities.push({
                name: activityName,
                params: params
            });
        });

        return {
            bearerToken: document.getElementById('activityApiKey')?.value || '',
            region: document.getElementById('activityRegion')?.value || '',
            assetId: document.getElementById('assetId')?.value || '',
            identity: document.getElementById('identity')?.value || '',
            activitySource: document.getElementById('activitySource')?.value || '',
            activities: activities
        };
    }

    /**
     * Load form state from local storage
     */
    loadFormState() {
        chrome.storage.local.get(['formData', 'activityFormData', 'v5FormData', 'activeContactVersion'], (result) => {
            // Load Active Version logic
            const version = result.activeContactVersion || 'v2';
            if (this.handleVersionSwitch) this.handleVersionSwitch(version, false);

            // Load V5 Data
            if (result.v5FormData) {
                 const data = result.v5FormData;
                 const setVal = (id, val) => { const el = document.getElementById(id); if (el) el.value = val || ''; };
                 
                 setVal('regionV5', data.region);
                 setVal('apiKeyV5', data.apiKey);
                 setVal('operationV5', data.operation || 'create');
                 setVal('contactTypeV5', data.contactType || 'identified');
                 setVal('audienceIdV5', data.audienceId);
                 setVal('identityV5', data.identity);

                 const sysContainer = document.getElementById('systemAttributesContainerV5');
                 if(sysContainer) sysContainer.innerHTML = '';
                 if (data.systemAttributes && Array.isArray(data.systemAttributes)) {
                     data.systemAttributes.forEach(attr => this.addAttributeRowV5('system', attr.key, attr.value, attr.type));
                 }
                 
                 const custContainer = document.getElementById('customAttributesContainerV5');
                 if(custContainer) custContainer.innerHTML = '';
                 if (data.customAttributes && Array.isArray(data.customAttributes)) {
                     data.customAttributes.forEach(attr => this.addAttributeRowV5('custom', attr.key, attr.value, attr.type));
                 }

                 if (this.toggleIdentityField) this.toggleIdentityField(data.contactType || 'identified');
            }

            if (result.formData) {
                const data = result.formData;

                document.getElementById('region').value = data.region || '';
                document.getElementById('apiKey').value = data.apiKey || '';
                document.getElementById('activity').value = data.activity || '';
                document.getElementById('listId').value = data.listId || '';

                // Load Primary Key
                if (data.primaryKey) {
                    document.getElementById('primaryKey').value = data.primaryKey.key || '';
                    document.getElementById('primaryValue').value = data.primaryKey.value || '';
                    document.getElementById('primaryType').value = data.primaryKey.dataType || 'string';
                }

                if (data.attributes && data.attributes.length > 0) {
                    document.getElementById('attributesContainer').innerHTML = '';
                    data.attributes.forEach(attr => {
                        this.addAttributeRow(attr.key, attr.value, attr.dataType);
                    });
                }
            }

            if (result.activityFormData) {
                const actData = result.activityFormData;

                const activityApiKey = document.getElementById('activityApiKey');
                const activityRegion = document.getElementById('activityRegion');
                const assetId = document.getElementById('assetId');
                const identity = document.getElementById('identity');
                const activitySource = document.getElementById('activitySource');
                const activitiesContainer = document.getElementById('activitiesContainer');

                if (activityApiKey) activityApiKey.value = actData.bearerToken || '';
                if (activityRegion) activityRegion.value = actData.region || '';
                if (assetId) assetId.value = actData.assetId || '';
                if (identity) identity.value = actData.identity || '';
                if (activitySource) activitySource.value = actData.activitySource || '';

                if (activitiesContainer && actData.activities && actData.activities.length > 0) {
                    activitiesContainer.innerHTML = '';
                    actData.activities.forEach(activity => {
                        this.addActivityRow(activity.name, activity.params);
                    });
                }
            }
        });
    }

    /**
     * Add call to history
     */
    addToHistory(callData) {
        chrome.storage.local.get(['callHistory'], (result) => {
            const history = result.callHistory || [];
            const call = {
                id: Date.now(),
                timestamp: new Date().toLocaleString(),
                apiType: callData.apiType || 'contact',
                region: callData.region,
                apiKey: callData.apiKey, // Store API Key
                activity: callData.activity,
                listId: callData.listId,
                attributes: callData.attributes,
                response: callData.response,
                status: callData.status
            };
            
            // For Activity API calls, store additional fields needed for history restoration
            if (callData.apiType === 'activity') {
                call.identity = callData.identity;
                call.activitySource = callData.activitySource;
                call.activities = callData.activities;
                call.historyPayload = callData.historyPayload;
            }

            // For Contact API V5 calls
            if (callData.apiType === 'contact_v5') {
                call.operation = callData.operation;
                call.contactType = callData.contactType;
                call.audienceId = callData.audienceId;
                call.identity = callData.identity;
                call.systemAttributes = callData.systemAttributes;
                call.customAttributes = callData.customAttributes;
            }
            
            history.unshift(call);
            if (history.length > 50) history.pop();
            chrome.storage.local.set({ callHistory: history });
        });
    }

    /**
     * Load and display call history
     */
    loadHistory() {
        chrome.storage.local.get(['callHistory'], (result) => {
            const history = result.callHistory || [];
            const historyContainer = document.getElementById('historyContainer');
            
            if (!historyContainer) return;
            
            if (history.length === 0) {
                historyContainer.innerHTML = '<p class="no-history">No call history yet</p>';
                return;
            }

            historyContainer.innerHTML = history.map(call => {
                const apiType = call.apiType || 'contact';
                let apiLabel = 'CONTACT API';
                let badgeColor = '#f1f8e9'; // Greenish
                let activityText = call.activity || '';
                let detailsText = '';
                let buttonText = 'Restore';
                
                if (apiType === 'activity') {
                    apiLabel = 'ACTIVITY API';
                    badgeColor = '#e3f2fd'; // Blueish
                    detailsText = 'activities';
                    buttonText = 'View cURL';
                } else if (apiType === 'contact_v5') {
                    apiLabel = 'CONTACT V5';
                    badgeColor = '#fff3e0'; // Orangeish
                    activityText = call.operation;
                    detailsText = `${call.contactType}`;
                } else {
                    // Contact V2
                    detailsText = `${Array.isArray(call.attributes) ? call.attributes.length : 0} attributes`;
                    buttonText = 'Restore';
                }
                
                return `
                    <div class="history-item" data-call-id="${call.id}" data-api-type="${apiType}" style="margin-bottom: 10px; padding: 10px; border: 1px solid #ddd; border-radius: 4px; background-color: #fafafa;">
                        <div class="history-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                            <span class="history-time" style="font-size: 12px; color: #666;">${call.timestamp}</span>
                            <span class="history-api-type" style="font-weight: bold; margin-left: 10px; padding: 2px 8px; background-color: ${badgeColor}; border-radius: 3px;">${apiLabel}</span>
                            <span class="history-activity" style="margin-left: 10px; font-weight: 500; flex: 1;">${activityText}</span>
                            <span class="history-status" style="margin-left: 10px; padding: 2px 8px; border-radius: 3px; background-color: ${call.status >= 200 && call.status < 300 ? '#c8e6c9' : '#ffcdd2'}; color: ${call.status >= 200 && call.status < 300 ? '#2e7d32' : '#c62828'}; font-weight: bold;">
                                ${call.status}
                            </span>
                        </div>
                        <div class="history-details" style="margin-bottom: 8px;">
                            <small style="color: #999;">${call.region} | ${detailsText}</small>
                        </div>
                        <div style="display: flex; gap: 8px;">
                            <button class="btn-history-restore" data-call-id="${call.id}" style="padding: 6px 12px; background-color: #1976d2; color: white; border: none; border-radius: 3px; cursor: pointer; font-size: 12px;">${buttonText}</button>
                            ${apiType === 'contact' ? `<button class="btn-history-view-curl" data-call-id="${call.id}" style="padding: 6px 12px; background-color: #5bc0de; color: white; border: none; border-radius: 3px; cursor: pointer; font-size: 12px;">View cURL</button>` : ''}
                        </div>
                    </div>
                `;
            }).join('');

            document.querySelectorAll('.btn-history-restore').forEach(btn => {
                btn.addEventListener('click', (e) => this.restoreFromHistory(e.target.dataset.callId));
            });

            document.querySelectorAll('.btn-history-view-curl').forEach(btn => {
                btn.addEventListener('click', (e) => this.viewCurlFromHistory(e.target.dataset.callId));
            });
        });
    }

    /**
     * View cURL from history (Contact API)
     */
    viewCurlFromHistory(callId) {
        chrome.storage.local.get(['callHistory'], (result) => {
            const history = result.callHistory || [];
            const call = history.find(c => c.id == callId);
            
            if (call && call.apiType === 'contact') {
                const endpoint = ENDPOINTS[call.region];
                const queryParams = APIHandler.buildQueryParams(document.getElementById('apiKey').value || 'YOUR_API_KEY', call.activity, call.listId);
                
                // Reconstruct attributes
                const allAttributes = [];
                if (Array.isArray(call.attributes)) {
                    allAttributes.push(...call.attributes);
                }

                const bodyParams = APIHandler.buildRequestBody(allAttributes);
                const curl = APIHandler.generateCurl(endpoint, queryParams, bodyParams);
                
                this.displayCurl(curl);
                Utils.showStatus(document.getElementById('statusMessage'), 'cURL generated from history', 'info');
            }
        });
    }

    /**
     * Restore a previous call from history
     */
    restoreFromHistory(callId) {
        chrome.storage.local.get(['callHistory'], (result) => {
            const history = result.callHistory || [];
            const call = history.find(c => c.id == callId);
            
            if (call) {
                const apiType = call.apiType || 'contact';
                
                if (apiType === 'contact') {
                    // Switch to V2 tab
                    this.handleVersionSwitch('v2');

                    document.getElementById('region').value = call.region;
                    if (call.apiKey) document.getElementById('apiKey').value = call.apiKey; // Restore API Key
                    document.getElementById('activity').value = call.activity;
                    document.getElementById('listId').value = call.listId || '';
                    
                    document.getElementById('attributesContainer').innerHTML = '';
                    if (Array.isArray(call.attributes)) {
                        call.attributes.forEach(attr => {
                            if (attr.key && attr.value !== undefined) {
                                this.addAttributeRow(attr.key, attr.value, attr.dataType || DATA_TYPES.string);
                            }
                        });
                    }
                    this.saveFormState();
                    Utils.showStatus(document.getElementById('statusMessage'), 'History restored!', 'success');
                } else if (apiType === 'activity') {
                    // Generate cURL for Activity API from history
                    this.generateActivityCurlFromHistory(call);
                    
                    // Also restore form values for activity if needed
                    document.getElementById('activityRegion').value = call.region;
                     if (call.apiKey) document.getElementById('activityApiKey').value = call.apiKey;
                    if (call.listId) document.getElementById('assetId').value = call.listId; // assetId was stored as listId
                    if (call.identity) document.getElementById('identity').value = call.identity;
                    if (call.activitySource) document.getElementById('activitySource').value = call.activitySource;
                    
                    if (call.activities && call.activities.length > 0) {
                         const container = document.getElementById('activitiesContainer');
                         container.innerHTML = '';
                         call.activities.forEach(activity => {
                            this.addActivityRow(activity.name, activity.params);
                         });
                    }

                } else if (apiType === 'contact_v5') {
                    // Switch to V5 tab
                    this.handleVersionSwitch('v5');
                    
                    if (call.region) document.getElementById('regionV5').value = call.region;
                    if (call.apiKey) document.getElementById('apiKeyV5').value = call.apiKey; // Restore V5 API Key
                    if (call.operation) document.getElementById('operationV5').value = call.operation;
                    if (call.contactType) document.getElementById('contactTypeV5').value = call.contactType;
                    if (call.audienceId) document.getElementById('audienceIdV5').value = call.audienceId;
                    if (call.identity) document.getElementById('identityV5').value = call.identity;
                    
                    // Clear and restore attributes
                    document.getElementById('systemAttributesContainerV5').innerHTML = '';
                    if (Array.isArray(call.systemAttributes)) {
                        call.systemAttributes.forEach(attr => this.addAttributeRowV5('system', attr.key, attr.value, attr.dataType));
                    }
                    
                    document.getElementById('customAttributesContainerV5').innerHTML = '';
                    if (Array.isArray(call.customAttributes)) {
                        call.customAttributes.forEach(attr => this.addAttributeRowV5('custom', attr.key, attr.value, attr.dataType));
                    }
                    
                    this.toggleIdentityField(call.contactType || 'identified');
                    this.saveFormState();
                    Utils.showStatus(document.getElementById('statusMessage'), 'History restored!', 'success');
                }
            }
        });
    }

    /**
     * Generate Activity API cURL from history data
     */
    generateActivityCurlFromHistory(call) {
        try {
            const statusMessage = document.getElementById('statusMessage');
            
            console.log('History call data:', call);
            console.log('historyPayload from history:', call.historyPayload);
            
            // If we have the exact payload from history, use it directly (most reliable)
            if (call.historyPayload && Array.isArray(call.historyPayload) && call.historyPayload.length > 0) {
                const bearerToken = document.getElementById('activityApiKey').value.trim();
                if (!bearerToken) {
                    Utils.showStatus(statusMessage, 'Please enter your Activity API Bearer Token to generate cURL', 'warning', 4000);
                    return;
                }

                // Generate cURL directly from stored payload
                const curl = APIHandler.generateActivityCurl(bearerToken, call.region, call.historyPayload);
                this.displayCurl(curl);
                
                // Show informative message
                const numActivities = call.historyPayload.length;
                const message = `Activity API cURL generated from history (${numActivities} activities restored with full parameters)`;
                Utils.showStatus(statusMessage, message, 'info', 5000);
                return;
            }
            
            // Fallback: reconstruct from activities or activity names
            const activities = call.activities && call.activities.length > 0 ? call.activities : (
                Array.isArray(call.attributes) ? call.attributes.map(actName => ({
                    activity_name: actName,
                    activity_params: {}
                })) : []
            );
            
            if (activities.length === 0) {
                Utils.showStatus(statusMessage, 'No activity data available in history', 'error', 4000);
                return;
            }

            // Use stored identity and source, or fallback to defaults
            const identity = call.identity || 'restored_identity';
            const activitySource = call.activitySource || 'history_restore';

            // Build payload using API Handler
            const payload = APIHandler.buildActivityPayload(call.listId, identity, activitySource, activities);
            
            // Get bearer token from form (user needs to provide it)
            const bearerToken = document.getElementById('activityApiKey').value.trim();
            if (!bearerToken) {
                Utils.showStatus(statusMessage, 'Please enter your Activity API Bearer Token to generate cURL', 'warning', 4000);
                return;
            }

            // Generate cURL
            const curl = APIHandler.generateActivityCurl(bearerToken, call.region, payload);
            this.displayCurl(curl);
            
            // Show informative message
            const message = `Activity API cURL generated from history (${activities.length} activities). Identity: ${identity}, Source: ${activitySource}`;
            Utils.showStatus(statusMessage, message, 'info', 5000);
        } catch (error) {
            Utils.showStatus(document.getElementById('statusMessage'), `Error: ${error.message}`, 'error', 4000);
        }
    }

    // --- V5 Methods ---

    /**
     * Handle Contact API Version Switch
     */
    handleVersionSwitch(version, saveState = true) {
        document.querySelectorAll('.api-type-btn[data-version]').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.version === version);
        });

        document.getElementById('contact-v2-container').style.display = version === 'v2' ? 'block' : 'none';
        document.getElementById('contact-v5-container').style.display = version === 'v5' ? 'block' : 'none';
        
        if (saveState) {
            this.saveFormState();
        }
    }

    /**
     * Add attribute row for V5 (system or custom)
     */
    addAttributeRowV5(type, key = '', value = '', dataType = DATA_TYPES.string) {
        const containerId = type === 'system' ? 'systemAttributesContainerV5' : 'customAttributesContainerV5';
        const container = document.getElementById(containerId);
        
        const rowId = `attr-${Date.now()}-${Math.random()}`;
        const row = document.createElement('div');
        row.className = 'attribute-row';
        row.id = rowId;
        
        row.innerHTML = `
            <input type="text" class="attr-key" placeholder="${type === 'system' ? 'Key (e.g., email)' : 'Key (e.g., CITY)'}" value="${key}" style="flex: 1;">
            <input type="text" class="attr-value" placeholder="Value" value="${value}" style="flex: 1;">
            <select class="attr-type" style="flex: 0.8;">
                <option value="${DATA_TYPES.string}" ${dataType === DATA_TYPES.string ? 'selected' : ''}>String</option>
                <option value="${DATA_TYPES.float}" ${dataType === DATA_TYPES.float ? 'selected' : ''}>Float</option>
                <option value="${DATA_TYPES.number}" ${dataType === DATA_TYPES.number ? 'selected' : ''}>Number</option>
                <option value="${DATA_TYPES.date}" ${dataType === DATA_TYPES.date ? 'selected' : ''}>Date</option>
            </select>
            <button class="btn-remove" style="background: none; border: none; color: #dc3545; cursor: pointer; font-size: 18px;">&times;</button>
        `;

        container.appendChild(row);

        // Add listeners
        row.querySelectorAll('input, select').forEach(el => {
            el.addEventListener('change', () => this.saveFormState());
        });
        
        // Auto-casing
        const keyInput = row.querySelector('.attr-key');
        keyInput.addEventListener('blur', (e) => {
            if (type === 'system') e.target.value = e.target.value.toLowerCase();
            if (type === 'custom') e.target.value = e.target.value.toUpperCase();
            this.saveFormState();
        });

        row.querySelector('.btn-remove').addEventListener('click', () => {
             row.remove();
             this.saveFormState();
        });
    }

    toggleIdentityField(type) {
        const identityGroup = document.getElementById('identityV5Group');
        if (identityGroup) {
             identityGroup.style.display = type === 'identified' ? 'block' : 'none';
        }
    }
    
    toggleApiKeyVisibilityV5() {
        const input = document.getElementById('apiKeyV5');
        const btn = document.getElementById('toggleApiKeyV5');
        if (input.type === 'password') {
            input.type = 'text';
            btn.textContent = 'Hide';
        } else {
            input.type = 'password';
            btn.textContent = 'Show';
        }
    }

    handleClearContactFormV5() {
        if (confirm('Clear V5 form?')) {
            document.getElementById('regionV5').value = '';
            document.getElementById('apiKeyV5').value = '';
            document.getElementById('operationV5').value = 'create';
            document.getElementById('contactTypeV5').value = 'identified';
            document.getElementById('audienceIdV5').value = '';
            document.getElementById('identityV5').value = '';
            document.getElementById('systemAttributesContainerV5').innerHTML = '';
            document.getElementById('customAttributesContainerV5').innerHTML = '';
            this.toggleIdentityField('identified');
            this.saveFormState();
        }
    }

    getV5FormData() {
        const region = document.getElementById('regionV5').value;
        const apiKey = document.getElementById('apiKeyV5').value;
        const operation = document.getElementById('operationV5').value;
        const contactType = document.getElementById('contactTypeV5').value;
        const audienceId = document.getElementById('audienceIdV5').value;
        const identity = document.getElementById('identityV5').value;

        const systemAttributes = [];
        document.querySelectorAll('#systemAttributesContainerV5 .attribute-row').forEach(row => {
            const key = row.querySelector('.attr-key').value.toLowerCase();
            const value = row.querySelector('.attr-value').value;
            const type = row.querySelector('.attr-type').value;
            if (key) systemAttributes.push({ key, value, type });
        });

        const customAttributes = [];
        document.querySelectorAll('#customAttributesContainerV5 .attribute-row').forEach(row => {
            const key = row.querySelector('.attr-key').value.toUpperCase();
            const value = row.querySelector('.attr-value').value;
            const type = row.querySelector('.attr-type').value;
             if (key) customAttributes.push({ key, value, type });
        });

        return {
            region, apiKey, operation, contactType, audienceId, identity, systemAttributes, customAttributes
        };
    }

    handleGenerateCurlV5() {
        const data = this.getV5FormData();
        if (!data.region) {
            Utils.showStatus(document.getElementById('statusMessage'), 'Region is required', 'error');
            return;
        }
        if (!data.apiKey) {
            Utils.showStatus(document.getElementById('statusMessage'), 'API Key is required', 'error');
            return;
        }
        if (data.contactType === 'identified' && !data.identity) {
             Utils.showStatus(document.getElementById('statusMessage'), 'Identity is required for identified contact', 'error');
             return;
        }

        const payload = APIHandler.buildV5Payload(data);
        const endpoint = `${CONTACT_V5_ENDPOINTS[data.region]}/${data.operation}`;

        const curl = APIHandler.generateV5Curl(endpoint, data.apiKey, payload);
        this.displayCurl(curl);
        Utils.showStatus(document.getElementById('statusMessage'), 'cURL generated', 'success');
    }

    async handleTriggerAPIV5() {
         const data = this.getV5FormData();
         if (!data.region || !data.apiKey) {
            Utils.showStatus(document.getElementById('statusMessage'), 'Region and API Key are required', 'error');
            return;
         }
         if (data.contactType === 'identified' && !data.identity) {
             Utils.showStatus(document.getElementById('statusMessage'), 'Identity is required for identified contact', 'error');
             return;
         }

         const payload = APIHandler.buildV5Payload(data);
         const endpoint = `${CONTACT_V5_ENDPOINTS[data.region]}/${data.operation}`;

         try {
             Utils.showStatus(document.getElementById('statusMessage'), 'Triggering V5 API...', 'info');
             const response = await APIHandler.triggerV5API(endpoint, data.apiKey, payload);
             const formatted = APIHandler.formatResponse(response);
             this.displayResponse(formatted);
             
             this.addToHistory({
                 apiType: 'contact_v5',
                 region: data.region,
                 apiKey: data.apiKey, // Save API Key
                 operation: data.operation,
                 contactType: data.contactType,
                 audienceId: data.audienceId,
                 identity: data.identity,
                 systemAttributes: data.systemAttributes,
                 customAttributes: data.customAttributes,
                 status: 200
             });
             
             Utils.showStatus(document.getElementById('statusMessage'), 'API Triggered', 'success');
         } catch(e) {
             Utils.showStatus(document.getElementById('statusMessage'), `Error: ${e.message}`, 'error', 4000);
         }
    }

    /**
     * Clear all history
     */
    clearHistory() {
        if (confirm('Are you sure you want to clear all call history?')) {
            chrome.storage.local.set({ callHistory: [] });
            this.loadHistory();
            Utils.showStatus(document.getElementById('statusMessage'), 'History cleared!', 'success');
        }
    }

    handleContactPreviewV5() {
        const data = this.getV5FormData();
        
        let tableHtml = `
            <div style="margin-bottom: 15px;">
                <strong>Contact Type:</strong> ${data.contactType}<br>
                <strong>Operation:</strong> ${data.operation}<br>
                ${data.contactType === 'identified' ? `<strong>Identity:</strong> ${data.identity}<br>` : ''}
                <strong>Audience ID:</strong> ${data.audienceId || '1 (Default)'}
            </div>
            <table style="width: 100%; border-collapse: collapse; margin-top: 10px; table-layout: fixed;">
                <thead>
                    <tr style="background-color: #f2f2f2;">
                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left; width: 20%;">Scope</th>
                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left; width: 40%;">Attribute Name</th>
                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left; width: 40%;">Value</th>
                    </tr>
                </thead>
                <tbody>
        `;

        if (data.systemAttributes) {
            data.systemAttributes.forEach(attr => {
                tableHtml += `
                    <tr>
                        <td style="border: 1px solid #ddd; padding: 8px;">System</td>
                        <td style="border: 1px solid #ddd; padding: 8px; word-break: break-all;">${attr.key}</td>
                        <td style="border: 1px solid #ddd; padding: 8px; word-break: break-all;">${attr.value}</td>
                    </tr>
                `;
            });
        }

        if (data.customAttributes) {
            data.customAttributes.forEach(attr => {
                tableHtml += `
                    <tr style="background-color: #f9f9f9;">
                         <td style="border: 1px solid #ddd; padding: 8px;">Custom</td>
                        <td style="border: 1px solid #ddd; padding: 8px; word-break: break-all;">${attr.key}</td>
                        <td style="border: 1px solid #ddd; padding: 8px; word-break: break-all;">${attr.value}</td>
                    </tr>
                `;
            });
        }

        tableHtml += `</tbody></table>`;
        this.showPreviewModal('Contact V5 Preview', tableHtml);
    }
}
